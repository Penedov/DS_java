/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectclass;

/**
 *
 * @author CAMARGO
 */




































public class Geladeira {
    String tipo;
    int quantidadeDePortas;
    String cor;
    String modelo;
    int valor;
    Boolean off_power;

        public String armazenar() {
             return("Sua geladeira está armazenando os itens");
        }

        public String refrigerar() {
             return("Sua geladeira está refrigerando");
        }

        public String congelar() {
            return ("Sua geladeira está congelando os itens");
        }

  
}
