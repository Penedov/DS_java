package com.mycompany.tax;

public class Tax {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[] salarios = new double[6];
        double totalImposto = 0;

        // Recebendo os salários
        for (int i = 0; i < salarios.length; i++) {
            System.out.print("Digite o valor do " + (i + 1) + "º salário: ");
            salarios[i] = scanner.nextDouble();
        }

        // Calculando imposto para cada salário
        for (int i = 0; i < salarios.length; i++) {
            double imposto = 0;
            if (salarios[i] <= 1000) {
                imposto = salarios[i] * 0.10; // 10% de imposto
            } else if (salarios[i] <= 3000) {
                imposto = salarios[i] * 0.15; // 15% de imposto
            } else {
                imposto = salarios[i] * 0.20; // 20% de imposto
            }
            totalImposto += imposto;
            System.out.println("Salário: R$ " + salarios[i] + " - Imposto: R$ " + imposto);
        }

        System.out.println("Total de imposto a ser pago: R$ " + totalImposto);
    }
}
