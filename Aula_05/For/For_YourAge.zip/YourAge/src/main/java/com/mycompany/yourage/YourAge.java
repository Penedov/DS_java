package com.mycompany.yourage;

public class YourAge {

    public static void main(String[] args) {
        int idade = 20; // Substitua com a sua idade
        
        System.out.println("Contando ate a sua idade usando for:");
        for (int i = 1; i <= idade; i++) {
            System.out.println("Ano " + i);
        }
        
        System.out.println("Voce tem " + idade + " anos.");
    }
}
