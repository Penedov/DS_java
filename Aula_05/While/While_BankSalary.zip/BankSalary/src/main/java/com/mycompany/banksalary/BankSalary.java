package com.mycompany.banksalary;

public class BankSalary {

    public static void main(String[] args) {
        double saldo = 1000.00;
        double deducao = 150.00; // Exemplo de dedução por iteração

        System.out.println("Simulando saldo do cartão salário usando while:");
        while (saldo > 0) {
            System.out.println("Saldo atual: R$ " + saldo);
            saldo -= deducao; // Deduz um valor do saldo
        }
        
        System.out.println("SEM SALDO NO BANCO.");
    }
}
