package com.mycompany.yourage;

public class YourAge {

    public static void main(String[] args) {
         int idade = 25; // Substitua com a sua idade
        int i = 1;
        
        System.out.println("Contando até a sua idade usando do-while:");
        do {
            System.out.println("Ano " + i);
            i++;
        } while (i <= idade);
        
        System.out.println("Você tem " + idade + " anos.");    }
}
