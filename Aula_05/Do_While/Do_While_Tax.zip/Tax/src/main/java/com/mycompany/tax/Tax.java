package com.mycompany.tax;

import java.util.Scanner;

public class Tax {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[] salarios = new double[6];
        double totalImposto = 0;
        int i = 0;

        // Recebendo os salários
        while (i < salarios.length) {
            System.out.print("Digite o valor do " + (i + 1) + "º salário: ");
            salarios[i] = scanner.nextDouble();
            i++;
        }

        i = 0; // Reiniciando o contador
        // Calculando imposto para cada salário
        while (i < salarios.length) {
            double imposto = 0;
            if (salarios[i] <= 1000) {
                imposto = salarios[i] * 0.10;
            } else if (salarios[i] <= 3000) {
                imposto = salarios[i] * 0.15;
            } else {
                imposto = salarios[i] * 0.20;
            }
            totalImposto += imposto;
            System.out.println("Salário: R$ " + salarios[i] + " - Imposto: R$ " + imposto);
            i++;
        }

        System.out.println("Total de imposto a ser pago: R$ " + totalImposto);
    }
}
